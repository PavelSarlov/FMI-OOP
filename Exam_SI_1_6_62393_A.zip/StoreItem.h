#pragma once
#include <iostream>

#ifndef STOREITEM_H
#define STOREITEM_H
enum productType {DEFAULT, VEGETABLE, FRUIT};

class StoreItem
{
public:
	StoreItem() {};
	StoreItem(productType, unsigned int, double, std::string name);
	StoreItem(const StoreItem& other);
	StoreItem& operator=(const StoreItem& other);

	productType getType() const;
	unsigned int getCalories() const;
	double getPrice() const;
	std::string getName() const;

	void setType(productType newType);
	void setCalories(unsigned int newCalories);
	void setPrice(double newPrice);
	void setName(std::string newName);

	virtual void print() const;

private:
	productType type = DEFAULT;
	unsigned int calories = 0;
	double price = 0;
	std::string name;
};
#endif // !STOREITEM_H
