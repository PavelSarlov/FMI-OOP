#include "StoreItem.h"

StoreItem::StoreItem(productType type, unsigned int calories, double price, std::string name)
{
	this->type = type;
	this->calories = calories;
	this->price = price;
	this->name = name;
}
StoreItem::StoreItem(const StoreItem& other)
{
	this->type = other.type;
	this->calories = other.calories;
	this->price = other.price;
	this->name = other.name;
}
StoreItem& StoreItem::operator=(const StoreItem& other)
{
	if (this != &other)
	{
		this->type = other.type;
		this->calories = other.calories;
		this->price = other.price;
		this->name = other.name;
	}
	return *this;
}

productType StoreItem::getType() const
{
	return this->type;
}
unsigned int StoreItem::getCalories() const
{
	return this->calories;
}
double StoreItem::getPrice() const
{
	return this->price;
}
std::string StoreItem::getName() const
{
	return this->name;
}

void StoreItem::setType(productType newType)
{
	this->type = newType;
}
void StoreItem::setCalories(unsigned int newCalories)
{
	this->calories = newCalories;
}
void StoreItem::setPrice(double newPrice)
{
	this->price = newPrice;
}
void StoreItem::setName(std::string newName)
{
	this->name = newName;
}

void StoreItem::print() const
{
	std::cout << "Name: " << this->name << std::endl;
	std::cout << "Type: " << this->type << std::endl;
	std::cout << "Calories: " << this->calories << std::endl;
	std::cout << "Price: " << this->price << std::endl << std::endl;
}