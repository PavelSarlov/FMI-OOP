#pragma once
#include <iostream>

template <class T>
class Matrix
{
public:
	Matrix();
	Matrix(unsigned int x, unsigned int y);
	Matrix(const Matrix&);
	Matrix& operator=(const Matrix&);
	~Matrix();

	void setAt(unsigned int x, unsigned int y, T element);
	T getAt(unsigned int x, unsigned int y) const;
	void transpose();

private:
	T** values;
	unsigned int sizeX = 2;
	unsigned int sizeY = 2;
};

template <class T>
Matrix<T>::Matrix()
{
	this->values = new T * [this->sizeX];
	for (unsigned int i = 0; i < this->sizeX; i++)
	{
		this->values[i] = new T[this->sizeY]();
	}
}
template <class T>
Matrix<T>::Matrix(unsigned int x, unsigned int y)
{
	this->sizeX = x;
	this->sizeY = y;
	this->values = new T * [x];
	for (unsigned int i = 0; i < x; i++)
	{
		this->values[i] = new T[y]();
	}
}
template <class T>
Matrix<T>::Matrix(const Matrix& other)
{
	this->sizeX = other.sizeX;
	this->sizeY = other.sizeY;
	this->values = new T * [other.sizeX];
	for (unsigned int i = 0; i < other.sizeX; i++)
	{
		this->values[i] = new T[other.sizeY];
		for (unsigned int j = 0; j < other.sizeY; j++)
		{
			this->values[i][j] = other.values[i][j];
		}
	}
}
template <class T>
Matrix<T>& Matrix<T>::operator=(const Matrix& other)
{
	if (this != &other)
	{
		for (unsigned int i = 0; i < this->sizeX; i++)
		{
			delete[] this->values[i];
		}
		delete[] this->values;

		this->sizeX = other.sizeX;
		this->sizeY = other.sizeY;
		this->values = new T * [other.sizeX];
		for (unsigned int i = 0; i < other.sizeX; i++)
		{
			this->values[i] = new T[other.sizeY];
			for (unsigned int j = 0; j < other.sizeY; j++)
			{
				this->values[i][j] = other.values[i][j];
			}
		}
	}
	return *this;
}
template <class T>
Matrix<T>::~Matrix()
{
	for (unsigned int i = 0; i < this->sizeX; i++)
	{
		delete[] this->values[i];
	}
	delete[] this->values;
}

template <class T>
void Matrix<T>::setAt(unsigned int x, unsigned int y, T element)
{
	if (x - 1 >= this->sizeX || y - 1 >= this->sizeY)
	{
		std::cout << "ERROR! Invalid coords.\n";
		return;
	}
	this->values[x - 1][y - 1] = element;
}
template <class T>
T Matrix<T>::getAt(unsigned int x, unsigned int y) const
{
	if (x - 1 >= this->sizeX || y - 1 >= this->sizeY)
	{
		std::cout << "ERROR! Invalid coords. First element will be returned.\n";
		return this->values[0][0];
	}
	return this->values[x - 1][y - 1];
}
template <class T>
void Matrix<T>::transpose()
{
	T** temp = new T * [this->sizeX];
	for (unsigned int i = 0; i < this->sizeX; i++)
	{
		temp[i] = new T[this->sizeY];
		for (unsigned int j = 0; j < this->sizeY; j++)
		{
			temp[i][j] = this->values[j][i];
		}
	}
	for (unsigned int i = 0; i < this->sizeX; i++)
	{
		delete[] this->values[i];
	}
	delete[] this->values;
	this->values = temp;
}