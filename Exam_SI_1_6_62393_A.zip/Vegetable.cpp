#include "Vegetable.h"

Vegetable::Vegetable(std::string name, std::string sort, unsigned int calories, double price) : StoreItem(FRUIT, calories, price, name)
{
	this->sort = sort;
}
Vegetable::Vegetable(const Vegetable& other)
{
	this->sort = other.sort;
}
Vegetable& Vegetable::operator=(const Vegetable& other)
{
	if (this != &other)
	{
		this->sort = other.sort;
	}
	return *this;
}

bool Vegetable::operator==(const Vegetable& other)
{
	if (this->sort == other.sort)
		return true;
	return false;
}

std::string Vegetable::getSort() const
{
	return this->sort;
}

void Vegetable::setSort(std::string newSort)
{
	this->sort = newSort;
}

void Vegetable::print() const
{
	std::cout << "Sort: " << this->sort << std::endl;
	StoreItem::print();
}