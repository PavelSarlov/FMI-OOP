#include "Fruit.h"

Fruit::Fruit(std::string name, std::string color, unsigned int calories, double price) : StoreItem(FRUIT, calories, price, name)
{
	this->color = color;
}
Fruit::Fruit(const Fruit& other)
{
	this->color = other.color;
}
Fruit& Fruit::operator=(const Fruit& other)
{
	if (this != &other)
	{
		this->color = other.color;
	}
	return *this;
}

bool Fruit::operator>(const StoreItem& other)
{
	if (this->getCalories() > other.getCalories())
		return true;
	return false;
}

void Fruit::setColor(std::string newColor)
{
	this->color = newColor;
}

void Fruit::print() const
{
	std::cout << "Color: " << this->color << std::endl;
	StoreItem::print();
}