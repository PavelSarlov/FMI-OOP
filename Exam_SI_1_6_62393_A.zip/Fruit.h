#pragma once

#ifndef FRUIT_H
#define FRUIT_H

#include "StoreItem.h"

class Fruit : public StoreItem
{
public:
	Fruit() {};
	Fruit(std::string name, std::string color, unsigned int calories, double price);
	Fruit(const Fruit& other);
	Fruit& operator=(const Fruit& other);

	bool operator>(const StoreItem& other);

	void setColor(std::string newColor);

	void print() const;

private:
	std::string color;
};

#endif // !FRUIT_H
