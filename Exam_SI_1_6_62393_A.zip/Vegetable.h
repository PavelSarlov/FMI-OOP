#pragma once

#ifndef VEGETABLE_H
#define VEGETABLE_H

#include "StoreItem.h"

class Vegetable : public StoreItem
{
public:
	Vegetable() {};
	Vegetable(std::string name, std::string sort, unsigned int calories, double price);
	Vegetable(const Vegetable& other);
	Vegetable& operator=(const Vegetable& other);

	bool operator==(const Vegetable& other);

	virtual std::string getSort() const;

	virtual void setSort(std::string newSort);

	void print() const;

private:
	std::string sort;
};
#endif
