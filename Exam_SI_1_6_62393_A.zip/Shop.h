#pragma once

#ifndef SHOP_H
#define SHOP_H


#include "StoreItem.h"
#include "Fruit.h"
#include "Vegetable.h"

class Shop
{
public:
	Shop();
	Shop(const Shop& other);
	Shop& operator=(const Shop& other);
	~Shop();

	void addProduct(StoreItem product);
	void removeProduct(unsigned int index);
	void changePrice(unsigned int index, double newPrice);
	void changeName(unsigned int index, std::string newName);
	void printProductsInfo() const;

private:
	StoreItem** products;
	unsigned int productsCount = 0;
};

#endif // !SHOP_H