#include "Shop.h"

Shop::Shop()
{
	this->products = new StoreItem*[0];
}
Shop::Shop(const Shop& other)
{
	this->products = new StoreItem*[other.productsCount];
	this->productsCount = other.productsCount;
	for (unsigned int i = 0; i < other.productsCount; i++)
	{
		this->products[i] = new StoreItem();
		*this->products[i] = *other.products[i];
	}
}
Shop& Shop::operator=(const Shop& other)
{
	if (this != &other)
	{
		for (unsigned int i = 0; i < this->productsCount; i++)
		{
			delete this->products[i];
		}
		delete[] this->products;

		this->products = new StoreItem * [other.productsCount];
		this->productsCount = other.productsCount;
		for (unsigned int i = 0; i < other.productsCount; i++)
		{
			this->products[i] = new StoreItem();
			*this->products[i] = *other.products[i];
		}
	}
	return *this;
}
Shop::~Shop()
{
	for (unsigned int i = 0; i < this->productsCount; i++)
	{
		delete this->products[i];
	}
	delete[] this->products;
}

void Shop::addProduct(StoreItem product)
{
	StoreItem** temp = new StoreItem*[this->productsCount + 1];
	for (unsigned int i = 0; i < this->productsCount; i++)
	{
		temp[i] = new StoreItem();
		*temp[i] = product;
	}
	for (unsigned int i = 0; i < this->productsCount; i++)
	{
		delete this->products[i];
	}
	delete[] this->products;
	this->products = temp;
	this->productsCount += 1;
}
void Shop::removeProduct(unsigned int index)
{
	StoreItem** temp = new StoreItem*[this->productsCount - 1];
	for (unsigned int i = 0, j = 0; i < this->productsCount; i++)
	{
		temp[i] = new StoreItem();
		if(i!=index)
			temp[j++] = this->products[i];
	}
	delete[] this->products;
	this->products = temp;
	this->productsCount -= 1;
}
void Shop::changePrice(unsigned int index, double newPrice)
{
	this->products[index]->setPrice(newPrice);
}
void Shop::changeName(unsigned int index, std::string newName)
{
	this->products[index]->setName(newName);
}
void Shop::printProductsInfo() const
{
	for (unsigned int i = 0; i < this->productsCount; i++)
	{
		this->products[i]->print();
	}
}