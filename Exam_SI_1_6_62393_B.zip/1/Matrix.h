#pragma once

template <class T>
class Matrix
{
public:
	Matrix();
	Matrix(unsigned int rows, unsigned int cols);
	Matrix(const Matrix& other);
	Matrix& operator=(const Matrix& other);
	~Matrix();

	void setAt(unsigned int x, unsigned int y, T element);

	T getAt(unsigned int x, unsigned int y) const;

	void transpose();

private:
	unsigned int rows = 2;
	unsigned int cols = 2;
	T** values;
};

template <class T>
Matrix<T>::Matrix()
{
	this->values = new T * [this->rows];
	for (int i = 0; i < 2; i++)
	{
		this->values[i] = new T[this->cols]();
	}
}

template <class T>
Matrix<T>::Matrix(unsigned int rows, unsigned int cols)
{
	this->values = new T * [rows];
	for (int i = 0; i < rows; i++)
	{
		this->values[i] = new T[cols]();
	}
	this->rows = rows;
	this->cols = cols;
}

template <class T>
Matrix<T>::Matrix(const Matrix& other)
{
	*this = other;
}

template <class T>
Matrix<T>& Matrix<T>::operator=(const Matrix& other)
{
	if (this != &other)
	{
		for (int i = 0; i < this->rows; i++)
		{
			delete[] this->values[i];
		}
		delete[] this->values;

		this->values = new T * [other.rows];
		for (int i = 0; i < other.rows; i++)
		{
			this->values[i] = new T[other.cols];
			for (int j = 0; j < other.cols; j++)
			{
				this->values[i][j] = other.values[i][j];
			}
		}
	}
	return *this;
}

template <class T>
Matrix<T>::~Matrix()
{
	for (int i = 0; i < this->rows; i++)
	{
		delete[] this->values[i];
	}
	delete[] this->values;
}

template <class T>
void Matrix<T>::setAt(unsigned int x, unsigned int y, T element)
{
	if (x - 1 < 0 || x - 1 > this->rows || y - 1 < 0 || y - 1 > this->cols)
	{
		return;
	}

	this->values[x - 1][y - 1] = element;
}

template <class T>
T Matrix<T>::getAt(unsigned int x, unsigned int y) const
{
	if (x - 1 < 0 || x - 1 > this->rows || y - 1 < 0 || y - 1 > this->cols)
	{
		return T();	// exception ?
	}

	return this->values[x - 1][y - 1];
}

template <class T>
void Matrix<T>::transpose()
{
	T** transposed = new T * [this->cols];
	for (int i = 0; i < this->cols; i++)
	{
		transposed[i] = new T[this->rows];
		for (int j = 0; j < this->rows; j++)
		{
			transposed[i][j] = this->values[j][i];
		}
	}

	for (int i = 0; i < this->rows; i++)
	{
		delete[] this->values[i];
	}
	delete[] this->values;
	this->values = transposed;
}