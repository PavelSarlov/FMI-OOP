#include <iostream>
#include "Restaurant.h"
#include "Food.h"
#include "Drink.h"

int main()
{
	Restaurant restaurant;

	Food t1;
	t1.setName("Pizza");
	t1.setSize(0.400);
	t1.setAmount(30);
	t1.setPrice(5.50);

	Drink t2;
	t2.setName("Water");
	t2.setAlcohol(0);
	t2.setAmount(100);
	t2.setPrice(2.80);

	Drink t3;
	t3.setName("Tonic");
	t3.setAlcohol(1);
	t3.setAmount(100);
	t3.setPrice(2.80);

	restaurant.addProduct(t1);
	restaurant.addProduct(t2);
	restaurant.addProduct(t3);
	restaurant.changeProductPrice(1, 1.80);

	restaurant.printProducts();
	std::cout << "-----------------------------------------" << std::endl;	// a little separator
	restaurant.printNonAlcoholicBeverages();
	std::cout << "-----------------------------------------" << std::endl;	// a little separator

	restaurant.removeProduct(0);

	restaurant.printProducts();

	return 0;
}