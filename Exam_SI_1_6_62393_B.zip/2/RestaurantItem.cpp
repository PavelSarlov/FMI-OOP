#include "RestaurantItem.h"
#include <iostream>
#include <iomanip>

RestaurantItem::RestaurantItem() {}
RestaurantItem::RestaurantItem(Type type, unsigned int stock, double price)
{
	this->type = type;
	this->amount = stock;
	this->price = price;
}
RestaurantItem::RestaurantItem(const RestaurantItem& other)
{
	*this = other;
}
RestaurantItem& RestaurantItem::operator=(const RestaurantItem& other)
{
	if (this != &other)
	{
		this->type = other.type;
		this->amount = other.amount;
		this->price = other.price;
	}
	return *this;
}

Type RestaurantItem::getType() const
{
	return this->type;
}
unsigned int RestaurantItem::getAmount() const
{
	return this->amount;
}
double RestaurantItem::getPrice() const
{
	return this->price;
}

void RestaurantItem::setType(Type newType)
{
	this->type = newType;
}
void RestaurantItem::setAmount(unsigned int newAmount)
{
	this->amount = newAmount;
}
void RestaurantItem::setPrice(double newPrice)
{
	if (newPrice > 0)
		this->price = newPrice;
}

void RestaurantItem::print() const
{
	std::cout << "Type: ";
	switch (this->type)
	{
	case FOOD:
		std::cout << "Food";
		break;
	case DRINK:
		std::cout << "Drink";
		break;
	}
	std::cout << std::endl;
	std::cout << "Amount: " << this->amount << std::endl;
	std::cout << std::fixed << std::setprecision(2) << "Price: " << this->price << " lv." << std::endl;
}