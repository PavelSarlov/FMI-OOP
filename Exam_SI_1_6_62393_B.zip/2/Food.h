#pragma once

#ifndef FOOD_H
#define FOOD_H

#include <string>
#include "RestaurantItem.h"

class Food : public RestaurantItem
{
public:
	Food();
	Food(std::string name, double weight, unsigned int stock, double price);
	Food(const Food& other);
	Food& operator=(const Food& other);

	bool operator>(const Food& other);

	std::string getName() const;

	void setName(std::string newName);
	void setSize(double newWeight);

	void print() const;

private:
	std::string name;
	double size = 0;
};

#endif