#include "Restaurant.h"
#include "Food.h"
#include "Drink.h"
#include <iostream>

Restaurant::Restaurant() {}
Restaurant::Restaurant(const Restaurant& other)
{
	*this = other;
}
Restaurant& Restaurant::operator=(const Restaurant& other)
{
	if (this != &other)
	{
		for (int i = 0; i < this->products.size(); i++)
		{
			delete this->products[i];
		}
		this->products.clear();

		for (int i = 0; i < other.products.size(); i++)
		{
			addProduct(*other.products[i]);
		}
	}
	return *this;
}
Restaurant::~Restaurant()
{
	for (int i = 0; i < this->products.size(); i++)
	{
		delete this->products[i];
	}
	this->products.clear();
}

void Restaurant::addProduct(const RestaurantItem& product)
{
	switch (product.getType())
	{
	case FOOD:
		this->products.push_back(new Food(dynamic_cast<const Food&>(product)));
		break;
	case DRINK:
		this->products.push_back(new Drink(dynamic_cast<const Drink&>(product)));
		break;
	}
}
void Restaurant::removeProduct(unsigned int index)
{
	if (index >= 0 && index < this->products.size())
	{
		delete this->products[index];
		this->products.erase(this->products.begin() + index);
	}
}

void Restaurant::changeProductPrice(unsigned int index, double newPrice)
{
	if (index >= 0 && index < this->products.size() && newPrice>0)
	{
		this->products[index]->setPrice(newPrice);
	}
}
void Restaurant::changeProductName(unsigned int index, std::string newName)
{
	if (index >= 0 && index < this->products.size())
	{
		this->products[index]->setName(newName);
	}
}

void Restaurant::printProducts()
{
	std::cout << "Products:" << std::endl;
	for (auto& product : this->products)
	{
		product->print();
	}
}
void Restaurant::printNonAlcoholicBeverages()
{
	std::cout << "Non-alcoholic beverages:" << std::endl;
	for (auto& product : this->products)
	{
		if (product->getType() == DRINK && !(product->operator>(Drink())))
		{
			product->print();
		}
	}
}