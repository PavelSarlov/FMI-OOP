#pragma once

#ifndef RESTAURANTITEM_H
#define RESTAURANTITEM_H

#include <string>

class Drink;	// need the declaration in order to use the class in operator>
class Food;

enum Type { FOOD, DRINK };

class RestaurantItem
{
public:
	RestaurantItem();
	RestaurantItem(Type type, unsigned int stock, double price);
	RestaurantItem(const RestaurantItem& other);
	RestaurantItem& operator=(const RestaurantItem& other);

	Type getType() const;
	unsigned int getAmount() const;
	double getPrice() const;

	void setType(Type newType);
	void setAmount(unsigned int newAmount);
	void setPrice(double newPrice);

	virtual void print() const;
	virtual void setName(std::string newName) {}
	virtual bool operator>(const Drink& other) { return true; }
	virtual bool operator>(const Food& other) { return true; }

private:
	Type type;
	unsigned int amount = 0;
	double price = 0;
};

#endif // !RESTAURANTITEM_H
