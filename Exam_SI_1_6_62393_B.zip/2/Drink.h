#pragma once

#ifndef DRINK_H
#define DRINK_H

#include <string>
#include "RestaurantItem.h"

class Drink : public RestaurantItem
{
public:
	Drink();
	Drink(std::string name, unsigned int alcoholContent, unsigned int stock, double price);
	Drink(const Drink& other);
	Drink& operator=(const Drink& other);

	bool operator>(const Drink& other);

	std::string getName() const;

	void setName(std::string newName);
	void setAlcohol(double newAlcoholcontent);

	void print() const;

private:
	std::string name;
	double alcoholContent = 0;
};

#endif