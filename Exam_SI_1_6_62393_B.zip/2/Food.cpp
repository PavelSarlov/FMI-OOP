#include "Food.h"
#include <iostream>
#include <iomanip>

Food::Food() : RestaurantItem()
{
	setType(FOOD);
}
Food::Food(std::string name, double weight, unsigned int stock, double price) : RestaurantItem(FOOD, stock, price)
{
	this->name = name;
	this->size = weight;
}
Food::Food(const Food& other)
{
	*this = other;
}
Food& Food::operator=(const Food& other)
{
	if (this != &other)
	{
		RestaurantItem::operator=(other);
		this->name = other.name;
		this->size = other.size;
	}
	return *this;
}

bool Food::operator>(const Food& other)
{
	if (this->size > other.size)
		return true;
	return false;
}

std::string Food::getName() const
{
	return this->name;
}

void Food::setName(std::string newName)
{
	this->name = newName;
}
void Food::setSize(double newWeight)
{
	if (newWeight > 0)
	{
		this->size = newWeight;
	}
}

void Food::print() const
{
	RestaurantItem::print();
	std::cout << "Name: " << this->name << std::endl;
	std::cout << std::fixed << std::setprecision(3) << "Size: " << this->size << "kg" << std::endl << std::endl;
}