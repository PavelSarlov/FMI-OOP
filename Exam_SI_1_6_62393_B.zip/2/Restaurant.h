#pragma once

#ifndef RESTAURANT_H
#define RESTAURANT_H

#include <vector>
#include <string>
#include "RestaurantItem.h"

class Restaurant
{
public:
	Restaurant();
	Restaurant(const Restaurant& other);
	Restaurant& operator=(const Restaurant& other);
	~Restaurant();

	void addProduct(const RestaurantItem& product);
	void removeProduct(unsigned int index);
	
	void changeProductPrice(unsigned int index, double newPrice);
	void changeProductName(unsigned int index, std::string newName);

	void printProducts();
	void printNonAlcoholicBeverages();

private:
	std::vector<RestaurantItem*> products;
};

#endif