#include "Drink.h"
#include <iostream>
#include <iomanip>

Drink::Drink() : RestaurantItem()
{
	setType(DRINK);
}
Drink::Drink(std::string name, unsigned int alcoholContent, unsigned int stock, double price) : RestaurantItem(DRINK, stock, price)
{
	this->name = name;
	this->alcoholContent = alcoholContent;
}
Drink::Drink(const Drink& other)
{
	*this = other;
}
Drink& Drink::operator=(const Drink& other)
{
	if (this != &other)
	{
		RestaurantItem::operator=(other);
		this->name = other.name;
		this->alcoholContent = other.alcoholContent;
	}
	return *this;
}

bool Drink::operator>(const Drink& other)
{
	if (this->alcoholContent > other.alcoholContent)
		return true;
	return false;
}

std::string Drink::getName() const
{
	return this->name;
}

void Drink::setName(std::string newName)
{
	this->name = newName;
}
void Drink::setAlcohol(double newAlcoholcontent)
{
	if (newAlcoholcontent >= 0)
	{
		this->alcoholContent = newAlcoholcontent;
	}	
}

void Drink::print() const
{
	RestaurantItem::print();
	std::cout << "Name: " << this->name << std::endl;
	std::cout << std::fixed << std::setprecision(2) << "Alcohol content: " << this->alcoholContent << "%" << std::endl << std::endl;
}